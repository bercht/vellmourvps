// app/javascript/application.js
import "@hotwired/turbo-rails"
import "./controllers"

console.log("🔥 Application.js carregado via Importmap!");
